/*
	Copyright (c) 2004-2010, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dijit._Calendar"]){dojo._hasResource["dijit._Calendar"]=true;dojo.provide("dijit._Calendar");dojo.require("dijit.Calendar");dojo.deprecated("dijit._Calendar is deprecated","dijit._Calendar moved to dijit.Calendar",1.5);dijit._Calendar=dijit.Calendar;}